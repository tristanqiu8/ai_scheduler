# scenario package initialization
"""
Scenario definitions for AI Scheduler
"""

from .real_task import create_real_tasks

__all__ = ['create_real_tasks']
