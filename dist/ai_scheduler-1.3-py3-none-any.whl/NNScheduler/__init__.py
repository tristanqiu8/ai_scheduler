"""
NNScheduler - Neural Network Task Scheduler
"""

__version__ = "1.3"
