"""Packaged sample JSON configurations for AI Scheduler."""
