#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Scheduler - Neural Network Task Scheduler with Priority Optimization

Version: 1.0.0preview
Maintainer: Tristan.Qiu
Team: AIC (AI Computing)
Description: Neural Network Task Scheduler with Priority Optimization

This package provides both command-line and programmatic interfaces
for optimizing neural network task scheduling on NPU and DSP resources.
"""

__version__ = "1.0.0preview"
__maintainer__ = "Tristan.Qiu"
__team__ = "AIC"
__description__ = "Neural Network Task Scheduler with Priority Optimization"

# 导入主要的API接口
from .core.optimization_api import OptimizationAPI

# 延迟导入OptimizationInterface以避免循环导入问题
OptimizationInterface = None

def _get_optimization_interface():
    """延迟导入OptimizationInterface"""
    global OptimizationInterface
    if OptimizationInterface is None:
        try:
            from .NNScheduler.interface.optimization_interface import OptimizationInterface as OI
            OptimizationInterface = OI
        except ImportError:
            # 如果导入失败，创建一个简化版本
            OptimizationInterface = None
    return OptimizationInterface

# 便捷的函数接口
def optimize_from_json(config_file, output_dir="./artifacts"):
    """
    便捷函数：从JSON配置文件运行优化

    Args:
        config_file (str): JSON配置文件路径
        output_dir (str): 输出目录路径，默认为 "./artifacts"

    Returns:
        dict: 优化结果

    Example:
        >>> import ai_scheduler
        >>> result = ai_scheduler.optimize_from_json("config.json", "output/")
        >>> print(f"满足率: {result['best_configuration']['satisfaction_rate']:.1%}")
    """
    api = OptimizationAPI()
    return api.optimize_from_json(config_file, output_dir)

def create_optimizer(config_dict=None):
    """
    创建优化器实例

    Args:
        config_dict (dict, optional): 配置字典，如果为None则使用默认配置

    Returns:
        OptimizationAPI: 优化器实例

    Example:
        >>> import ai_scheduler
        >>> optimizer = ai_scheduler.create_optimizer()
        >>> result = optimizer.optimize_from_json("config.json")
    """
    return OptimizationAPI(config_dict)

# 获取样本配置文件路径的函数
def get_sample_configs():
    """
    获取内置样本配置文件列表

    Returns:
        list: 样本配置文件路径列表
    """
    import os
    from pathlib import Path

    package_dir = Path(__file__).parent
    sample_dir = package_dir / "sample_config"

    if sample_dir.exists():
        return [str(f) for f in sample_dir.glob("*.json")]
    return []

def get_sample_config_path(name):
    """
    获取特定样本配置文件的完整路径

    Args:
        name (str): 配置文件名称（如 "config_1npu_1dsp.json"）

    Returns:
        str: 配置文件完整路径，如果文件不存在则返回None

    Example:
        >>> import ai_scheduler
        >>> config_path = ai_scheduler.get_sample_config_path("config_1npu_1dsp.json")
        >>> result = ai_scheduler.optimize_from_json(config_path)
    """
    import os
    from pathlib import Path

    package_dir = Path(__file__).parent
    config_path = package_dir / "sample_config" / name

    return str(config_path) if config_path.exists() else None

# 版本信息
def version_info():
    """
    获取版本信息

    Returns:
        dict: 包含版本、维护者、团队等信息的字典
    """
    return {
        "version": __version__,
        "maintainer": __maintainer__,
        "team": __team__,
        "description": __description__
    }

# 公开的API
__all__ = [
    "optimize_from_json",
    "create_optimizer",
    "OptimizationAPI",
    "get_sample_configs",
    "get_sample_config_path",
    "version_info",
    "__version__",
    "__maintainer__",
    "__team__",
    "__description__"
]

# 动态添加OptimizationInterface到__all__（如果可用）
def __getattr__(name):
    """处理动态属性访问"""
    if name == "OptimizationInterface":
        return _get_optimization_interface()
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")