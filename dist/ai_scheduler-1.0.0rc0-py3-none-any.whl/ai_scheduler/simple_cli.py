#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Scheduler 简化命令行接口

这个版本避免了复杂的导入依赖，提供基本的命令行功能
"""

import sys
import os
import argparse
import json
from pathlib import Path

from . import __version__, __maintainer__, __team__, __description__

def print_banner():
    """打印应用横幅"""
    print("=" * 80)
    print(f"  AI Scheduler - {__description__}")
    print("=" * 80)
    print(f"  Version: {__version__}")
    print(f"  Maintainer: {__maintainer__}")
    print(f"  Team: {__team__}")
    print("=" * 80)

def list_sample_configs():
    """列出可用的样本配置文件"""
    package_dir = Path(__file__).parent
    sample_dir = package_dir / "sample_config"

    if not sample_dir.exists():
        print("没有找到样本配置文件目录。")
        return

    configs = list(sample_dir.glob("*.json"))
    if not configs:
        print("没有找到样本配置文件。")
        return

    print("\n可用的样本配置文件:")
    print("-" * 60)

    for config_file in sorted(configs):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                config_data = json.load(f)

            scenario = config_data.get("scenario", {})
            scenario_name = scenario.get("scenario_name", config_file.stem)
            description = scenario.get("description", "无描述")

            print(f"  {config_file.name}")
            print(f"    场景: {scenario_name}")
            print(f"    描述: {description}")
            print(f"    路径: {config_file}")
            print()
        except Exception as e:
            print(f"  {config_file.name}")
            print(f"    错误: 无法读取配置文件 ({e})")
            print()

def validate_config_basic(config_file):
    """基本配置文件验证"""
    try:
        config_path = Path(config_file)
        if not config_path.exists():
            print(f"[ERROR] 配置文件不存在: {config_file}")
            return False

        with open(config_path, "r", encoding="utf-8") as f:
            config_data = json.load(f)

        # 基本结构验证
        required_sections = ["optimization", "resources", "scenario"]
        missing_sections = []

        for section in required_sections:
            if section not in config_data:
                missing_sections.append(section)

        if missing_sections:
            print(f"[ERROR] 缺少必需的配置段: {', '.join(missing_sections)}")
            return False

        # 验证resources结构
        if "resources" not in config_data["resources"]:
            print("[ERROR] resources段必须包含resources数组")
            return False

        # 验证scenario结构
        if "tasks" not in config_data["scenario"]:
            print("[ERROR] scenario段必须包含tasks数组")
            return False

        print("[SUCCESS] 配置文件格式正确")

        # 显示配置摘要
        print("\n配置摘要:")
        print("-" * 40)

        scenario = config_data["scenario"]
        print(f"场景名称: {scenario.get('scenario_name', '未指定')}")
        print(f"场景描述: {scenario.get('description', '无描述')}")
        print(f"任务数量: {len(scenario.get('tasks', []))}")

        resources = config_data["resources"].get("resources", [])
        print(f"资源数量: {len(resources)}")
        resource_types = {}
        for resource in resources:
            rtype = resource.get("resource_type", "Unknown")
            resource_types[rtype] = resource_types.get(rtype, 0) + 1
        for rtype, count in resource_types.items():
            print(f"  {rtype}: {count}")

        return True

    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON格式错误: {e}")
        return False
    except Exception as e:
        print(f"[ERROR] 验证失败: {e}")
        return False

def run_optimization_simple(config_file, output_dir, verbose=False):
    """使用简化的方式运行优化"""
    try:
        from .core.optimization_api import OptimizationAPI

        if verbose:
            print(f"[INFO] 配置文件: {config_file}")
            print(f"[INFO] 输出目录: {output_dir}")

        # 首先验证配置文件
        if not validate_config_basic(config_file):
            return False

        print(f"\n[INFO] 开始优化...")

        # 创建API实例并运行优化
        api = OptimizationAPI()
        result = api.optimize_from_json(config_file, output_dir)

        # 显示结果摘要
        best_config = result['best_configuration']
        print("\n" + "=" * 80)
        print("优化结果摘要")
        print("=" * 80)

        print(f"满足率: {best_config['satisfaction_rate']:.1%}")
        print(f"平均延迟: {best_config['avg_latency']:.1f}ms")

        if 'resource_utilization' in best_config:
            print("资源利用率:")
            for resource_type, utilization in best_config['resource_utilization'].items():
                print(f"  {resource_type}: {utilization:.1f}%")

        print(f"系统利用率: {best_config['system_utilization']:.1f}%")

        # FPS和延迟满足情况
        fps_satisfied = sum(1 for satisfied in best_config['fps_satisfaction'].values() if satisfied)
        total_tasks = len(best_config['fps_satisfaction'])
        print(f"\nFPS满足情况: {fps_satisfied}/{total_tasks}")

        latency_satisfied = sum(1 for satisfied in best_config['latency_satisfaction'].values() if satisfied)
        print(f"延迟满足情况: {latency_satisfied}/{total_tasks}")

        print("\n[SUCCESS] 优化完成！")
        return True

    except Exception as e:
        print(f"[ERROR] 优化失败: {e}")
        if verbose:
            import traceback
            traceback.print_exc()
        return False

def main():
    """简化的命令行主入口"""
    parser = argparse.ArgumentParser(
        description=f"AI Scheduler v{__version__} - {__description__}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
示例用法:
  python -m ai_scheduler.simple_cli config.json
  python -m ai_scheduler.simple_cli path/to/config.json --output results/
  python -m ai_scheduler.simple_cli --list-samples
  python -m ai_scheduler.simple_cli --validate config.json

维护者: {__maintainer__} (团队: {__team__})
        """
    )

    parser.add_argument(
        "config_file",
        nargs="?",
        help="JSON配置文件路径"
    )

    parser.add_argument(
        "-o", "--output",
        default="./artifacts",
        help="输出目录 (默认: ./artifacts)"
    )

    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"AI Scheduler {__version__}"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="启用详细输出"
    )

    parser.add_argument(
        "--no-banner",
        action="store_true",
        help="不显示横幅"
    )

    parser.add_argument(
        "--list-samples",
        action="store_true",
        help="列出可用的样本配置文件"
    )

    parser.add_argument(
        "--validate",
        action="store_true",
        help="只验证配置文件，不运行优化"
    )

    args = parser.parse_args()

    # 显示横幅（除非明确禁用）
    if not args.no_banner:
        print_banner()

    # 处理特殊命令
    if args.list_samples:
        list_sample_configs()
        return 0

    # 验证参数
    if not args.config_file:
        print("ERROR: 请指定配置文件路径")
        parser.print_help()
        return 1

    # 处理样本配置文件
    config_file = args.config_file
    if config_file.startswith("sample:"):
        sample_name = config_file[7:]  # 移除 "sample:" 前缀
        package_dir = Path(__file__).parent
        sample_path = package_dir / "sample_config" / sample_name

        if sample_path.exists():
            config_file = str(sample_path)
            if args.verbose:
                print(f"[INFO] 使用样本配置: {sample_name}")
        else:
            print(f"ERROR: 样本配置文件不存在: {sample_name}")
            print("使用 --list-samples 查看可用的样本配置")
            return 1

    # 验证配置文件是否存在
    if not Path(config_file).exists():
        print(f"ERROR: 配置文件不存在: {config_file}")
        return 1

    if args.verbose:
        print(f"[INFO] 配置文件: {config_file}")
        print(f"[INFO] 输出目录: {args.output}")

    # 只验证模式
    if args.validate:
        success = validate_config_basic(config_file)
        return 0 if success else 1

    # 运行优化
    success = run_optimization_simple(config_file, args.output, args.verbose)
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())