#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Scheduler Core Optimization API

This module provides the main OptimizationAPI class that serves as the
programmatic interface for the AI Scheduler package.
"""

import os
import sys
import json
import time
from pathlib import Path
from typing import Optional, Dict, Any, Union

class OptimizationAPI:
    """
    AI Scheduler优化API

    提供程序化接口来运行神经网络任务调度优化。
    支持从JSON配置文件或配置字典运行优化。
    """

    def __init__(self, config_dict: Optional[Dict[str, Any]] = None):
        """
        初始化优化API

        Args:
            config_dict (dict, optional): 配置字典，如果提供，将作为默认配置
        """
        self.default_config = config_dict
        self._setup_paths()

    def _setup_paths(self):
        """设置项目路径，确保能够导入NNScheduler模块"""
        # 获取包目录路径
        package_dir = Path(__file__).parent.parent

        # 确保包目录在Python路径中
        if str(package_dir) not in sys.path:
            sys.path.insert(0, str(package_dir))

    def optimize_from_json(self, config_file: Union[str, Path], output_dir: str = "./artifacts") -> Dict[str, Any]:
        """
        从JSON配置文件运行优化

        Args:
            config_file (str or Path): JSON配置文件路径
            output_dir (str): 输出目录路径

        Returns:
            dict: 优化结果，包含best_configuration等信息

        Raises:
            FileNotFoundError: 当配置文件不存在时
            ValueError: 当配置文件格式无效时
            RuntimeError: 当优化过程失败时

        Example:
            >>> api = OptimizationAPI()
            >>> result = api.optimize_from_json("config.json", "output/")
            >>> print(f"满足率: {result['best_configuration']['satisfaction_rate']:.1%}")
        """
        # 转换为Path对象并验证文件存在
        config_path = Path(config_file)
        if not config_path.exists():
            # 如果是相对路径，尝试在包的sample_config目录中查找
            if not config_path.is_absolute():
                package_dir = Path(__file__).parent.parent
                sample_config_path = package_dir / "sample_config" / config_path.name
                if sample_config_path.exists():
                    config_path = sample_config_path
                else:
                    raise FileNotFoundError(f"配置文件不存在: {config_file}")

        # 确保配置文件路径是绝对路径，避免切换工作目录后找不到文件
        config_path = config_path.resolve()

        # 创建输出目录
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # 动态导入OptimizationInterface
        try:
            from ai_scheduler.NNScheduler.interface.optimization_interface import OptimizationInterface
        except ImportError as e:
            raise RuntimeError(f"无法导入优化模块: {e}")

        # 创建优化接口并执行优化
        try:
            optimizer_interface = OptimizationInterface()

            # 切换到输出目录执行优化
            original_cwd = os.getcwd()
            try:
                os.chdir(output_path)
                print(f"[INFO] 开始优化，配置文件: {config_path}")
                start_time = time.time()

                result = optimizer_interface.optimize_from_json(str(config_path))

                elapsed_time = time.time() - start_time
                print(f"[INFO] 优化完成，耗时: {elapsed_time:.1f}秒")

                return result

            finally:
                os.chdir(original_cwd)

        except Exception as e:
            raise RuntimeError(f"优化过程失败: {e}")

    def optimize_from_dict(self, config_dict: Dict[str, Any], output_dir: str = "./artifacts") -> Dict[str, Any]:
        """
        从配置字典运行优化

        Args:
            config_dict (dict): 配置字典
            output_dir (str): 输出目录路径

        Returns:
            dict: 优化结果

        Example:
            >>> config = {
            ...     "optimization": {"max_iterations": 50},
            ...     "resources": {"resources": [...]},
            ...     "scenario": {"tasks": [...]}
            ... }
            >>> api = OptimizationAPI()
            >>> result = api.optimize_from_dict(config, "output/")
        """
        # 创建临时JSON文件
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        temp_config_file = output_path / "temp_config.json"

        try:
            # 写入临时配置文件
            with open(temp_config_file, "w", encoding="utf-8") as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)

            # 使用JSON文件接口
            result = self.optimize_from_json(temp_config_file, output_dir)

            return result

        finally:
            # 清理临时文件
            if temp_config_file.exists():
                temp_config_file.unlink()

    def validate_config(self, config_file: Union[str, Path]) -> Dict[str, Any]:
        """
        验证配置文件格式

        Args:
            config_file (str or Path): 配置文件路径

        Returns:
            dict: 验证结果，包含 'valid' (bool) 和 'errors' (list) 字段

        Example:
            >>> api = OptimizationAPI()
            >>> validation = api.validate_config("config.json")
            >>> if validation['valid']:
            ...     print("配置文件有效")
            ... else:
            ...     print("错误:", validation['errors'])
        """
        try:
            config_path = Path(config_file)
            if not config_path.exists():
                return {"valid": False, "errors": [f"文件不存在: {config_file}"]}

            # 读取并解析JSON
            with open(config_path, "r", encoding="utf-8") as f:
                config_data = json.load(f)

            # 基本结构验证
            errors = []
            required_sections = ["optimization", "resources", "scenario"]

            for section in required_sections:
                if section not in config_data:
                    errors.append(f"缺少必需的配置段: {section}")

            # 验证resources结构
            if "resources" in config_data:
                if "resources" not in config_data["resources"]:
                    errors.append("resources段必须包含resources数组")
                elif not isinstance(config_data["resources"]["resources"], list):
                    errors.append("resources.resources必须是数组")

            # 验证scenario结构
            if "scenario" in config_data:
                if "tasks" not in config_data["scenario"]:
                    errors.append("scenario段必须包含tasks数组")
                elif not isinstance(config_data["scenario"]["tasks"], list):
                    errors.append("scenario.tasks必须是数组")

            return {
                "valid": len(errors) == 0,
                "errors": errors,
                "config": config_data if len(errors) == 0 else None
            }

        except json.JSONDecodeError as e:
            return {"valid": False, "errors": [f"JSON格式错误: {e}"]}
        except Exception as e:
            return {"valid": False, "errors": [f"验证失败: {e}"]}

    def list_sample_configs(self) -> list:
        """
        列出可用的样本配置文件

        Returns:
            list: 样本配置文件信息列表，每个元素包含name和path字段
        """
        package_dir = Path(__file__).parent.parent
        sample_dir = package_dir / "sample_config"

        configs = []
        if sample_dir.exists():
            for config_file in sample_dir.glob("*.json"):
                try:
                    # 读取配置文件获取描述信息
                    with open(config_file, "r", encoding="utf-8") as f:
                        config_data = json.load(f)

                    scenario = config_data.get("scenario", {})
                    description = scenario.get("description", "无描述")
                    scenario_name = scenario.get("scenario_name", config_file.stem)

                    configs.append({
                        "name": config_file.name,
                        "path": str(config_file),
                        "scenario_name": scenario_name,
                        "description": description
                    })
                except Exception:
                    # 如果无法读取配置，只添加基本信息
                    configs.append({
                        "name": config_file.name,
                        "path": str(config_file),
                        "scenario_name": config_file.stem,
                        "description": "配置文件读取失败"
                    })

        return sorted(configs, key=lambda x: x["name"])